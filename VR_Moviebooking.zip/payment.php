<?php
include 'config.php';
$show_id = $_POST['show_id'] ?? 0;
$seat_ids = $_POST['seat_ids'] ?? '';
if(!$seat_ids) die("No seats selected.");
$seat_array = explode(',', $seat_ids);

$stmt = $pdo->prepare("SELECT s.id AS show_id, s.show_time, t.name AS theater_name, m.title AS movie_title
                       FROM shows s
                       JOIN theaters t ON s.theater_id = t.id
                       JOIN movies m ON s.movie_id = m.id
                       WHERE s.id=?");
$stmt->execute([$show_id]);
$show = $stmt->fetch();
if(!$show) die("Show not found.");

$placeholders = implode(',', array_fill(0, count($seat_array), '?'));
$stmt2 = $pdo->prepare("SELECT seat_code FROM seats WHERE id IN ($placeholders)");
$stmt2->execute($seat_array);
$selected_seats = $stmt2->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Payment - VR Theater</title>
<link rel="stylesheet" href="style.css">
<style>.qr{width:200px;height:200px;margin:20px auto;display:block;}
.payment-container{text-align:center;margin-top:20px;}button{padding:10px 20px;margin-top:10px;cursor:pointer;}</style>
</head>
<body>
<div class="payment-container">
<h1>Payment - VR Theater</h1>
<p>Movie: <strong><?php echo $show['movie_title']; ?></strong></p>
<p>Show Time: <strong><?php echo date('d M Y H:i', strtotime($show['show_time'])); ?></strong></p>
<p>Theater: <strong><?php echo $show['theater_name']; ?></strong></p>
<p>Seats: <strong><?php echo implode(', ', $selected_seats); ?></strong></p>
<p>Pay via UPI:</p>
<img src="images/upi_qr.png" alt="UPI QR" class="qr">

<form action="book_seats.php" method="post">
    <input type="hidden" name="show_id" value="<?php echo $show_id; ?>">
    <input type="hidden" name="seat_ids" value="<?php echo $seat_ids; ?>">
    <button type="submit">Done Payment & Book Seats</button>
</form>
<br>
<form action="index.php" method="get">
    <button>Back to Home</button>
</form>
</div>
</body>
</html>