-- Database setup
CREATE DATABASE IF NOT EXISTS vr_theater;
USE vr_theater;

-- Movies
CREATE TABLE movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    poster_image VARCHAR(100) NOT NULL
);
INSERT INTO movies (title, poster_image) VALUES ('Narsimha', 'narsimha.jpg'), ('Ramayan', 'ramayan.jpg');

-- Theaters
CREATE TABLE theaters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    rows_count INT NOT NULL,
    seats_per_row INT NOT NULL
);
INSERT INTO theaters (name, rows_count, seats_per_row) VALUES ('VR Theater', 5, 10);

-- Shows
CREATE TABLE shows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT,
    theater_id INT,
    show_time DATETIME,
    FOREIGN KEY(movie_id) REFERENCES movies(id),
    FOREIGN KEY(theater_id) REFERENCES theaters(id)
);
INSERT INTO shows (movie_id, theater_id, show_time) VALUES
(1, 1, DATE_ADD(NOW(), INTERVAL 1 HOUR)),
(2, 1, DATE_ADD(NOW(), INTERVAL 2 HOUR));

-- Seats
CREATE TABLE seats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    theater_id INT,
    row_label CHAR(1),
    seat_number INT,
    seat_code VARCHAR(10),
    FOREIGN KEY(theater_id) REFERENCES theaters(id)
);

-- Generate seats A1-A10, B1-B10...
INSERT INTO seats (theater_id, row_label, seat_number, seat_code) VALUES
(1, 'A', 1, 'A1'),(1, 'A', 2, 'A2'),(1, 'A', 3, 'A3'),(1, 'A', 4, 'A4'),(1, 'A', 5, 'A5'),(1, 'A', 6, 'A6'),(1, 'A', 7, 'A7'),(1, 'A', 8, 'A8'),(1, 'A', 9, 'A9'),(1, 'A', 10, 'A10'),
(1, 'B', 1, 'B1'),(1, 'B', 2, 'B2'),(1, 'B', 3, 'B3'),(1, 'B', 4, 'B4'),(1, 'B', 5, 'B5'),(1, 'B', 6, 'B6'),(1, 'B', 7, 'B7'),(1, 'B', 8, 'B8'),(1, 'B', 9, 'B9'),(1, 'B', 10, 'B10'),
(1, 'C', 1, 'C1'),(1, 'C', 2, 'C2'),(1, 'C', 3, 'C3'),(1, 'C', 4, 'C4'),(1, 'C', 5, 'C5'),(1, 'C', 6, 'C6'),(1, 'C', 7, 'C7'),(1, 'C', 8, 'C8'),(1, 'C', 9, 'C9'),(1, 'C', 10, 'C10'),
(1, 'D', 1, 'D1'),(1, 'D', 2, 'D2'),(1, 'D', 3, 'D3'),(1, 'D', 4, 'D4'),(1, 'D', 5, 'D5'),(1, 'D', 6, 'D6'),(1, 'D', 7, 'D7'),(1, 'D', 8, 'D8'),(1, 'D', 9, 'D9'),(1, 'D', 10, 'D10'),
(1, 'E', 1, 'E1'),(1, 'E', 2, 'E2'),(1, 'E', 3, 'E3'),(1, 'E', 4, 'E4'),(1, 'E', 5, 'E5'),(1, 'E', 6, 'E6'),(1, 'E', 7, 'E7'),(1, 'E', 8, 'E8'),(1, 'E', 9, 'E9'),(1, 'E', 10, 'E10');

-- Bookings
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    show_id INT,
    booking_time DATETIME,
    FOREIGN KEY(show_id) REFERENCES shows(id)
);

-- Booking Seats
CREATE TABLE booking_seats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT,
    show_id INT,
    seat_id INT,
    FOREIGN KEY(booking_id) REFERENCES bookings(id),
    FOREIGN KEY(show_id) REFERENCES shows(id),
    FOREIGN KEY(seat_id) REFERENCES seats(id)
);