<?php
include 'config.php';
$show_id = $_GET['show_id'] ?? 0;
$stmt = $pdo->prepare("SELECT s.id AS show_id, s.show_time, t.id AS theater_id, t.name, t.rows_count, t.seats_per_row
                       FROM shows s JOIN theaters t ON s.theater_id=t.id WHERE s.id=?");
$stmt->execute([$show_id]);
$show = $stmt->fetch();
if(!$show) die("Show not found.");

$stmt2 = $pdo->prepare("SELECT * FROM seats WHERE theater_id=? ORDER BY row_label, seat_number");
$stmt2->execute([$show['theater_id']]);
$seats = $stmt2->fetchAll();

$stmt3 = $pdo->prepare("SELECT seat_id FROM booking_seats WHERE show_id=?");
$stmt3->execute([$show_id]);
$booked = $stmt3->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Select Seats</title>
<link rel="stylesheet" href="style.css">
<style>
.seats-container { display:flex; flex-direction:column; align-items:center; margin-top:20px; }
.seat-row { display:flex; justify-content:center; margin-bottom:10px; }
.seat { width:40px;height:40px;margin:3px;line-height:40px;background:#8bc34a;color:#fff;
        border-radius:5px;cursor:pointer;text-align:center;user-select:none;}
.seat.booked{background:#f44336;cursor:not-allowed;}
.seat.selected{background:#2196F3;}
.row-label{font-weight:bold;margin-right:10px;align-self:center;}
</style>
</head>
<body>
<h1 style="text-align:center;">Select Seats - <?php echo date('d M Y H:i', strtotime($show['show_time'])); ?> (<?php echo $show['name']; ?>)</h1>

<form id="seatForm" action="payment.php" method="post" style="text-align:center;">
    <input type="hidden" name="show_id" value="<?php echo $show_id; ?>">
    <div class="seats-container">
    <?php
    $current_row='';
    foreach($seats as $seat){
        if($seat['row_label'] != $current_row){
            if($current_row != '') echo "</div>";
            echo '<div class="seat-row"><span class="row-label">'.$seat['row_label'].'</span>';
            $current_row=$seat['row_label'];
        }
        $cls = in_array($seat['id'], $booked)?'seat booked':'seat';
        echo '<div class="'.$cls.'" data-seat="'.$seat['id'].'">'.$seat['seat_code'].'</div>';
    }
    echo "</div>";
    ?>
    </div>
    <br>
    <input type="hidden" name="seat_ids" id="seat_ids">
    <button type="submit">Proceed to Payment</button>
</form>

<script>
const seats=document.querySelectorAll('.seat');
let selected=[];
seats.forEach(s=>{
    if(!s.classList.contains('booked')){
        s.addEventListener('click', ()=>{
            const id=s.dataset.seat;
            if(selected.includes(id)){
                selected=selected.filter(x=>x!=id); 
                s.classList.remove('selected');
            } else {
                selected.push(id); 
                s.classList.add('selected');
            }
            document.getElementById('seat_ids').value=selected.join(',');
        });
    }
});
</script>
</body>
</html>