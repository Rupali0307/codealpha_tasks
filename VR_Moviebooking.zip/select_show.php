<?php
include 'config.php';
$movie_id = $_GET['movie_id'] ?? 0;

// Fetch movie
$stmt = $pdo->prepare("SELECT * FROM movies WHERE id=?");
$stmt->execute([$movie_id]);
$movie = $stmt->fetch();
if(!$movie) die("Movie not found.");

// Fetch shows
$stmt2 = $pdo->prepare("SELECT s.id, s.show_time, t.name AS theater_name
                        FROM shows s
                        JOIN theaters t ON s.theater_id=t.id
                        WHERE s.movie_id=? AND s.show_time >= NOW()
                        ORDER BY s.show_time ASC");
$stmt2->execute([$movie_id]);
$shows = $stmt2->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Select Show</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1 style="text-align:center;"><?php echo $movie['title']; ?> - Select Show</h1>

<div class="shows-container">
<?php foreach($shows as $show): ?>
    <div class="show-card">
        <h3><?php echo $show['theater_name']; ?></h3>
        <p><?php echo date('d M Y H:i', strtotime($show['show_time'])); ?></p>
        <form action="select_seats.php" method="get">
            <input type="hidden" name="show_id" value="<?php echo $show['id']; ?>">
            <button type="submit">Select Seats</button>
        </form>
    </div>
<?php endforeach; ?>
</div>

</body>
</html>