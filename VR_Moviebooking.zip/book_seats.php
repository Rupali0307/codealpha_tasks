<?php
include 'config.php';
$show_id = $_POST['show_id'] ?? 0;
$seat_ids = $_POST['seat_ids'] ?? '';
if(!$seat_ids) die("No seats selected.");
$seat_array = explode(',', $seat_ids);

try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO bookings (show_id, booking_time) VALUES (?, NOW())");
    $stmt->execute([$show_id]);
    $booking_id = $pdo->lastInsertId();

    $stmt2 = $pdo->prepare("INSERT INTO booking_seats (booking_id, show_id, seat_id) VALUES (?, ?, ?)");
    foreach($seat_array as $sid){
        $stmt2->execute([$booking_id, $show_id, $sid]);
    }
    $pdo->commit();
    echo "<script>alert('Booking Successful!');window.location='index.php';</script>";
} catch (Exception $e) {
    $pdo->rollBack();
    die("Booking failed: " . $e->getMessage());
}
?>