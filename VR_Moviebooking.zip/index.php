<?php
include 'config.php';
$stmt = $pdo->query("SELECT * FROM movies");
$movies = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>VR Theater - Movies</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>VR Theater - Book Your Movie</h1>
<div class="movies-container">
<?php foreach ($movies as $movie): ?>
<div class="movie">
    <img src="images/<?php echo $movie['poster_image']; ?>" alt="<?php echo $movie['title']; ?>">
    <h2><?php echo $movie['title']; ?></h2>
    <form action="select_show.php" method="get">
        <input type="hidden" name="movie_id" value="<?php echo $movie['id']; ?>">
        <button type="submit">Book Show</button>
    </form>
</div>
<?php endforeach; ?>
</div>
</body>
</html>