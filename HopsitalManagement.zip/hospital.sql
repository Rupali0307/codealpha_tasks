-- Create Database
CREATE DATABASE IF NOT EXISTS hospital;
USE hospital;

-- Table: Departments
CREATE TABLE Departments (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL,
    description TEXT
);

-- Table: Doctors
CREATE TABLE Doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    phone VARCHAR(15),
    email VARCHAR(100),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES Departments(dept_id)
);

-- Table: Patients
CREATE TABLE Patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other'),
    dob DATE,
    phone VARCHAR(15),
    address TEXT,
    blood_group VARCHAR(5)
);

-- Table: Appointments
CREATE TABLE Appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    appointment_date DATE,
    appointment_time TIME,
    status ENUM('Scheduled','Completed','Cancelled') DEFAULT 'Scheduled',
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
);

-- Table: Staff
CREATE TABLE Staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    role VARCHAR(50),
    phone VARCHAR(15),
    email VARCHAR(100),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES Departments(dept_id)
);

-- Table: Rooms
CREATE TABLE Rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL,
    type ENUM('General','ICU','Private'),
    availability BOOLEAN DEFAULT TRUE
);

-- Table: Billing
CREATE TABLE Billing (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    total_amount DECIMAL(10,2),
    paid_amount DECIMAL(10,2),
    bill_date DATE,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

-- Table: MedicalRecords
CREATE TABLE MedicalRecords (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    diagnosis TEXT,
    prescription TEXT,
    record_date DATE,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
);

-- Insert some sample data
INSERT INTO Departments (dept_name, description) VALUES
('Cardiology', 'Heart related treatments'),
('Neurology', 'Brain and nervous system treatments'),
('Orthopedics', 'Bone and joint care');

INSERT INTO Doctors (name, specialization, phone, email, dept_id) VALUES
('Dr. A Sharma', 'Cardiologist', '9876543210', 'a.sharma@hospital.com', 1),
('Dr. R Mehta', 'Neurologist', '9876543211', 'r.mehta@hospital.com', 2),
('Dr. P Kumar', 'Orthopedic', '9876543212', 'p.kumar@hospital.com', 3);

INSERT INTO Patients (name, gender, dob, phone, address, blood_group) VALUES
('Rahul Singh', 'Male', '1995-06-10', '9123456780', 'Nagpur, India', 'B+'),
('Priya Verma', 'Female', '2001-03-22', '9876543210', 'Mumbai, India', 'O+');

INSERT INTO Appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES
(1, 1, '2025-09-20', '10:00:00'),
(2, 2, '2025-09-21', '11:30:00');
