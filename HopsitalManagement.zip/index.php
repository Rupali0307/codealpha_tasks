<?php
include 'config.php';

// Handle Add Patient
if(isset($_POST['add_patient'])){
    $stmt = $pdo->prepare("INSERT INTO patients (name, age, gender, contact, disease, admission_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['name'], $_POST['age'], $_POST['gender'], $_POST['contact'], $_POST['disease'], $_POST['admission_date']]);
    header("Location: index.php");
    exit();
}

// Handle Edit Patient
if(isset($_POST['edit_patient'])){
    $stmt = $pdo->prepare("UPDATE patients SET name=?, age=?, gender=?, contact=?, disease=?, admission_date=? WHERE id=?");
    $stmt->execute([$_POST['name'], $_POST['age'], $_POST['gender'], $_POST['contact'], $_POST['disease'], $_POST['admission_date'], $_POST['patient_id']]);
    header("Location: index.php");
    exit();
}

// Handle Delete Patient
if(isset($_GET['delete_patient'])){
    $stmt = $pdo->prepare("DELETE FROM patients WHERE id=?");
    $stmt->execute([$_GET['delete_patient']]);
    header("Location: index.php");
    exit();
}

// Handle Book Appointment
if(isset($_POST['book_appointment'])){
    $stmt = $pdo->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['patient_id'], $_POST['doctor_id'], $_POST['appointment_date'], $_POST['appointment_time']]);
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hospital Management Dashboard</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="dashboard-container">

    <h1>Hospital Management Dashboard</h1>

    <!-- Stats Cards -->
    <div class="cards-container">
        <?php
        $totalPatients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
        $totalDoctors = $pdo->query("SELECT COUNT(*) FROM doctors")->fetchColumn();
        $totalAppointments = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
        $upcomingAppointments = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date >= CURDATE()")->fetchColumn();
        ?>
        <div class="card stat-card">
            <i class="fas fa-user-injured"></i>
            <h2><?php echo $totalPatients; ?></h2>
            <p>Total Patients</p>
        </div>
        <div class="card stat-card">
            <i class="fas fa-user-md"></i>
            <h2><?php echo $totalDoctors; ?></h2>
            <p>Total Doctors</p>
        </div>
        <div class="card stat-card">
            <i class="fas fa-calendar-check"></i>
            <h2><?php echo $totalAppointments; ?></h2>
            <p>Total Appointments</p>
        </div>
        <div class="card stat-card">
            <i class="fas fa-clock"></i>
            <h2><?php echo $upcomingAppointments; ?></h2>
            <p>Upcoming Appointments</p>
        </div>
    </div>

    <!-- Forms -->
    <div class="forms-container">

        <!-- Add / Edit Patient -->
        <div class="card form-card">
            <h2>Add Patient</h2>
            <form method="POST">
                <input type="hidden" name="patient_id" id="patient_id">
                <input type="text" name="name" id="name" placeholder="Patient Name" required>
                <input type="number" name="age" id="age" placeholder="Age" required>
                <select name="gender" id="gender" required>
                    <option value="">Select Gender</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                </select>
                <input type="text" name="contact" id="contact" placeholder="Contact">
                <input type="text" name="disease" id="disease" placeholder="Disease">
                <input type="date" name="admission_date" id="admission_date" required>
                <button type="submit" name="add_patient" id="add_btn">Add Patient</button>
                <button type="submit" name="edit_patient" id="edit_btn" style="display:none;">Save Changes</button>
            </form>
        </div>

        <!-- Book Appointment -->
        <div class="card form-card">
            <h2>Book Appointment</h2>
            <form method="POST">
                <select name="patient_id" required>
                    <option value="">Select Patient</option>
                    <?php
                    $patients = $pdo->query("SELECT * FROM patients")->fetchAll();
                    foreach($patients as $p){
                        echo "<option value='".$p['id']."'>".$p['name']."</option>";
                    }
                    ?>
                </select>
                <select name="doctor_id" required>
                    <option value="">Select Doctor</option>
                    <?php
                    $doctors = $pdo->query("SELECT * FROM doctors")->fetchAll();
                    foreach($doctors as $d){
                        echo "<option value='".$d['id']."'>".$d['name']." (".$d['specialty'].")</option>";
                    }
                    ?>
                </select>
                <input type="date" name="appointment_date" required>
                <input type="time" name="appointment_time" required>
                <button type="submit" name="book_appointment">Book Appointment</button>
            </form>
        </div>
    </div>

    <!-- Patients Table -->
    <div class="card table-card">
        <h2>Patients List</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Contact</th>
                <th>Disease</th>
                <th>Admission Date</th>
                <th>Actions</th>
            </tr>
            <?php
            $patients = $pdo->query("SELECT * FROM patients")->fetchAll();
            foreach($patients as $p){
                echo "<tr>
                <td>".$p['id']."</td>
                <td>".$p['name']."</td>
                <td>".$p['age']."</td>
                <td>".$p['gender']."</td>
                <td>".$p['contact']."</td>
                <td>".$p['disease']."</td>
                <td>".$p['admission_date']."</td>
                <td>
                    <button onclick='editPatient(".json_encode($p).")'>Edit</button>
                    <a href='?delete_patient=".$p['id']."' onclick='return confirm(\"Are you sure?\")'><button>Delete</button></a>
                </td>
                </tr>";
            }
            ?>
        </table>
    </div>

    <!-- Upcoming Appointments -->
    <div class="card table-card">
        <h2>Upcoming Appointments</h2>
        <?php include 'view_appointments.php'; ?>
    </div>

</div>

<script src="script.js"></script>
</body>
</html>
