function editPatient(patient){
    document.getElementById('patient_id').value = patient.id;
    document.getElementById('name').value = patient.name;
    document.getElementById('age').value = patient.age;
    document.getElementById('gender').value = patient.gender;
    document.getElementById('contact').value = patient.contact;
    document.getElementById('disease').value = patient.disease;
    document.getElementById('admission_date').value = patient.admission_date;

    document.getElementById('add_btn').style.display = 'none';
    document.getElementById('edit_btn').style.display = 'block';
}
