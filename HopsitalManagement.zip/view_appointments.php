<?php
$appointments = $pdo->query("SELECT a.id, p.name AS patient_name, d.name AS doctor_name, d.specialty, a.appointment_date, a.appointment_time
                             FROM appointments a
                             JOIN patients p ON a.patient_id = p.id
                             JOIN doctors d ON a.doctor_id = d.id
                             WHERE a.appointment_date >= CURDATE()
                             ORDER BY a.appointment_date ASC")->fetchAll();

if($appointments):
?>
<table>
    <tr>
        <th>ID</th>
        <th>Patient</th>
        <th>Doctor</th>
        <th>Specialty</th>
        <th>Date</th>
        <th>Time</th>
    </tr>
    <?php foreach($appointments as $a): ?>
    <tr>
        <td><?php echo $a['id']; ?></td>
        <td><?php echo $a['patient_name']; ?></td>
        <td><?php echo $a['doctor_name']; ?></td>
        <td><?php echo $a['specialty']; ?></td>
        <td><?php echo $a['appointment_date']; ?></td>
        <td><?php echo $a['appointment_time']; ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php else: ?>
<p>No upcoming appointments.</p>
<?php endif; ?>
